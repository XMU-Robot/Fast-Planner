#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose/cmake-build-debug/devel/lib:$LD_LIBRARY_PATH"
export PATH="/opt/ros/kinetic/bin:/home/ray/.nvm/versions/node/v8.16.0/bin:/home/ray/.cargo/bin:/home/ray/ROS/cartographer_ws/install_isolated/bin:/home/ray/bin:/home/ray/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/opt/gcc-arm-none-eabi-9-2020-q2-update/bin"
export PKG_CONFIG_PATH="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PYTHONPATH="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose/cmake-build-debug/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/ray/ROS/fast_planner_ws/src/Fast-Planner/simu_tool/tf_to_pose:/home/ray/ROS/open_vins_ws/src/open_vins/ov_core:/home/ray/ROS/open_vins_ws/src/open_vins/ov_data:/home/ray/ROS/open_vins_ws/src/open_vins/ov_eval:/home/ray/ROS/open_vins_ws/src/open_vins/ov_msckf:/home/ray/ROS/safe_landing_planner_ws/src/safe_landing_planner:/home/ray/ROS/fast_search_slam_ws/src:/home/ray/MT/ROS/safe_landing_planner_01_result_ws/src/safe_landing_planner:/home/ray/MT/simulation/avoidance_ws/src/avoidance/avoidance:/home/ray/MT/simulation/avoidance_ws/src/avoidance/global_planner:/home/ray/MT/simulation/avoidance_ws/src/avoidance/local_planner:/home/ray/MT/ROS/safe_landing_planner_landing_ws/src/safe_landing_planner:/home/ray/MT/simulation/mavros_ws/src:/home/ray/MT/ROS/safe_landing_planner_multi_frame_ws/src/safe_landing_planner:/home/ray/MT/ROS/safe_landing_planner_master_ws/src/safe_landing_planner:/opt/ros/kinetic/share"